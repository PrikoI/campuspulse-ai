@echo off
cd /d "%~dp0"
set CAMPUSPULSE_MODE=local
set CAMPUSPULSE_ALLOW_CLOUD=0
set CAMPUSPULSE_TRANSPORT=mcp
if not exist ".venv\Scripts\python.exe" (
  echo First install Python 3.11+ and run setup instructions in README.md.
  pause
  exit /b 1
)
echo Open http://127.0.0.1:8765 in your browser.
echo Connect your free Gemini key inside the app. Paid cloud deployment stays disabled.
".venv\Scripts\python.exe" -m campuspulse.server
pause
